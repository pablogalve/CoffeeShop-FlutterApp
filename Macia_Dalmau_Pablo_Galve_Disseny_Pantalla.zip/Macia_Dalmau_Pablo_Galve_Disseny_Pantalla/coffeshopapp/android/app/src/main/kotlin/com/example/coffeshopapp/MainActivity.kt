package com.example.coffeshopapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
